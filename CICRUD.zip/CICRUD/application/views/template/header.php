<html>
<head>
    
    <title>Belajar MVC di CodeIgniter</title>
</head>
<body>
    <h1><?php echo $judul?></h1>